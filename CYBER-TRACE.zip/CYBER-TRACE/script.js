/* ============================================================
   CyberTrace — Geospatial Intelligence Investigator
   Complete working JS — Nominatim + Wikimedia + Leaflet
   ============================================================ */

const STORAGE_KEYS = {
  CASES: "cybertrace_cases",
  EVIDENCE: "cybertrace_evidence",
  HISTORY: "cybertrace_history",
};

const NOMINATIM_URL = "https://nominatim.openstreetmap.org/search";
const WIKI_API = "https://commons.wikimedia.org/w/api.php";
const CONTACT_EMAIL = "investigator@example.com"; // Nominatim policy requires identification

let currentLocation = null;
let geoMap = null, mainMap = null, dashMap = null;
let geoMarker = null, mainMarker = null;

/* ---------- Utilities ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

function loadStore(k, fb) { try { return JSON.parse(localStorage.getItem(k)) ?? fb; } catch { return fb; } }
function saveStore(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { showToast("Storage full", true); } }

let toastTimer;
function showToast(msg, err = false) {
  const t = $("#toast");
  t.textContent = msg;
  t.classList.toggle("error", err);
  t.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove("show"), 3200);
}

function escapeHtml(s) {
  return String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function nowISO() { return new Date().toISOString(); }
function fmtDate(iso) { return iso ? new Date(iso).toLocaleString() : "—"; }
function genCaseId() {
  return `CT-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
}
function el(tag, attrs = {}, children = []) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "text") n.textContent = v;
    else if (k === "class") n.className = v;
    else if (k.startsWith("on") && typeof v === "function") n.addEventListener(k.slice(2).toLowerCase(), v);
    else if (v != null) n.setAttribute(k, v);
  }
  [].concat(children).forEach(c => { if (c != null) n.appendChild(typeof c === "string" ? document.createTextNode(c) : c); });
  return n;
}

/* ---------- Clock ---------- */
function startClock() {
  const el = $("#clock");
  const tick = () => el.textContent = new Date().toLocaleString();
  tick(); setInterval(tick, 1000);
}

/* ---------- Navigation ---------- */
function initNav() {
  $$(".nav-item").forEach(btn => {
    btn.addEventListener("click", () => {
      switchView(btn.dataset.view);
      if (window.innerWidth <= 820) $("#sidebar").classList.remove("open");
    });
  });
  $("#menuToggle").addEventListener("click", () => $("#sidebar").classList.toggle("open"));
}
function switchView(name) {
  $$(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.view === name));
  $$(".view").forEach(v => v.classList.toggle("active", v.id === `view-${name}`));
  if (name === "dashboard") { initDashMap(); refreshStats(); renderRecentActivity(); renderDashTimeline(); }
  if (name === "geo") { initGeoMap(); renderGeoRecent(); }
  if (name === "map") { initMainMap(); if (currentLocation) updateMainMap(currentLocation); }
  if (name === "gallery") renderFullGallery();
  if (name === "cases") renderCases();
  if (name === "evidence") { renderCases(); renderEvidence(); }
  if (name === "history") renderFullHistory();
  if (name === "report") renderCases();
}

/* ---------- Leaflet maps ---------- */
const OSM_TILES = "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
const OSM_ATTR = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';

function makeMap(id) {
  const m = L.map(id, { center: [20, 0], zoom: 2 });
  L.tileLayer(OSM_TILES, { attribution: OSM_ATTR, maxZoom: 19 }).addTo(m);
  return m;
}
function initGeoMap() { if (geoMap) return; geoMap = makeMap("geoMap"); setTimeout(() => geoMap.invalidateSize(), 200); }
function initMainMap() { if (mainMap) return; mainMap = makeMap("mainMap"); setTimeout(() => mainMap.invalidateSize(), 200); }
function initDashMap() {
  if (dashMap) return;
  dashMap = makeMap("dashMap");
  const cases = loadStore(STORAGE_KEYS.CASES, []);
  cases.forEach(c => (c.locations || []).forEach(l => {
    if (typeof l.lat === "number" && typeof l.lon === "number") {
      L.marker([l.lat, l.lon]).addTo(dashMap).bindPopup(`<b>${escapeHtml(l.name)}</b>`);
    }
  }));
  setTimeout(() => dashMap.invalidateSize(), 200);
}
function updateGeoMap(loc) {
  initGeoMap();
  if (geoMarker) geoMap.removeLayer(geoMarker);
  geoMarker = L.marker([loc.lat, loc.lon]).addTo(geoMap);
  geoMarker.bindPopup(`<b>${escapeHtml(loc.name)}</b><br>${escapeHtml(loc.display_name)}`).openPopup();
  geoMap.setView([loc.lat, loc.lon], 14);
  setTimeout(() => geoMap.invalidateSize(), 100);
}
function updateMainMap(loc) {
  initMainMap();
  if (mainMarker) mainMap.removeLayer(mainMarker);
  mainMarker = L.marker([loc.lat, loc.lon]).addTo(mainMap);
  mainMarker.bindPopup(`<b>${escapeHtml(loc.name)}</b><br>${escapeHtml(loc.display_name)}`).openPopup();
  mainMap.setView([loc.lat, loc.lon], 14);
  setTimeout(() => mainMap.invalidateSize(), 100);
}
function initMapFs() {
  const toggle = (sel, getter) => {
    const wrap = $(sel);
    const target = wrap.querySelector(".geo-map, .full-map");
    target.classList.toggle("fullscreen-map");
    setTimeout(() => getter()?.invalidateSize(), 250);
  };
  $("#geoMapFs").addEventListener("click", () => toggle(".geo-map-wrap", () => geoMap));
  $("#mainMapFs").addEventListener("click", () => toggle(".map-full-wrap", () => mainMap));
}

/* ---------- Nominatim ---------- */
async function searchNominatim(query) {
  const url = `${NOMINATIM_URL}?format=jsonv2&q=${encodeURIComponent(query)}&addressdetails=1&limit=8&accept-language=en&email=${encodeURIComponent(CONTACT_EMAIL)}`;
  const res = await fetch(url, { headers: { Accept: "application/json" } });
  if (!res.ok) throw new Error(`Nominatim ${res.status}`);
  return res.json();
}

/* ---------- Wikimedia ---------- */
async function fetchWikiPhotos(name) {
  const params = new URLSearchParams({
    action: "query", format: "json", origin: "*",
    generator: "search", gsrsearch: `${name} filetype:bitmap`,
    gsrnamespace: "6", gsrlimit: "12",
    prop: "imageinfo", iiprop: "url|extmetadata", iiurlwidth: "400"
  });
  const res = await fetch(`${WIKI_API}?${params}`);
  if (!res.ok) throw new Error("Commons request failed");
  const data = await res.json();
  const pages = data?.query?.pages || {};
  return Object.values(pages).map(p => {
    const info = p.imageinfo?.[0]; if (!info) return null;
    const meta = info.extmetadata || {};
    return {
      title: p.title || "Untitled",
      thumb: info.thumburl || info.url,
      fullUrl: info.descriptionurl || info.url,
      author: meta.Artist?.value ? stripHtml(meta.Artist.value) : "Unknown",
      license: meta.LicenseShortName?.value || "See source",
    };
  }).filter(Boolean);
}
function stripHtml(h) { const d = document.createElement("div"); d.innerHTML = h; return d.textContent || ""; }

/* ---------- Geo search ---------- */
function initGeoSearch() {
  const input = $("#geoInput"), btn = $("#geoSearchBtn"), clear = $("#geoClearBtn");
  btn.addEventListener("click", () => runGeoSearch(input.value));
  input.addEventListener("keydown", e => { if (e.key === "Enter") runGeoSearch(input.value); });
  clear.addEventListener("click", () => {
    input.value = "";
    setFeedback("");
    $("#geoResults").innerHTML = '<li class="empty">No search performed yet.</li>';
    $("#geoDetailsPanel").style.display = "none";
    $("#geoGalleryPanel").style.display = "none";
    currentLocation = null;
    if (geoMarker && geoMap) { geoMap.removeLayer(geoMarker); geoMarker = null; }
  });
  const gInput = $("#globalSearchInput"), gBtn = $("#globalSearchBtn");
  const go = () => {
    const q = gInput.value.trim();
    if (!q) return;
    $("#geoInput").value = q;
    switchView("geo");
    runGeoSearch(q);
  };
  gBtn.addEventListener("click", go);
  gInput.addEventListener("keydown", e => { if (e.key === "Enter") go(); });

  $("#copyCoordsBtn").addEventListener("click", copyCoords);
  $("#saveLocationBtn").addEventListener("click", saveCurrentLocationToCase);
}
function setFeedback(msg, type = "") {
  const f = $("#geoFeedback");
  f.textContent = msg;
  f.className = "feedback " + type;
}
async function runGeoSearch(raw) {
  const q = (raw || "").trim();
  if (!q) return setFeedback("Please enter a location.", "error");
  if (q.length < 2) return setFeedback("Query too short.", "error");
  setFeedback("Querying Nominatim…", "loading");
  $("#geoResults").innerHTML = '<li class="empty">Searching…</li>';
  $("#geoDetailsPanel").style.display = "none";
  $("#geoGalleryPanel").style.display = "none";
  try {
    const results = await searchNominatim(q);
    if (!results.length) {
      setFeedback("No matching location found.", "error");
      $("#geoResults").innerHTML = '<li class="empty">No results.</li>';
      recordHistory(q, null);
      return;
    }
    setFeedback(`${results.length} result(s). Select one to investigate.`, "ok");
    renderGeoResults(results);
    recordHistory(q, results[0]);
  } catch (e) {
    console.error(e);
    setFeedback("Geospatial service error. Try again.", "error");
    $("#geoResults").innerHTML = '<li class="empty">Search failed.</li>';
  }
}
function renderGeoResults(results) {
  const ul = $("#geoResults"); ul.innerHTML = "";
  results.forEach(r => {
    const li = el("li", {}, [
      el("strong", { text: r.name || r.display_name?.split(",")[0] || "Unnamed" }),
      el("div", { class: "muted small", text: r.display_name || "" }),
      el("div", { class: "mono small", text: `${r.type || "place"} • ${r.lat}, ${r.lon}` })
    ]);
    li.addEventListener("click", () => {
      $$("#geoResults li").forEach(x => x.classList.remove("active"));
      li.classList.add("active");
      selectLocation(r);
    });
    ul.appendChild(li);
  });
}
async function selectLocation(r) {
  const loc = {
    name: r.name || r.display_name?.split(",")[0] || "Unnamed",
    display_name: r.display_name || "",
    lat: parseFloat(r.lat), lon: parseFloat(r.lon),
    type: r.type || "", category: r.category || r.class || "",
    country: r.address?.country || "",
    region: r.address?.state || r.address?.region || r.address?.county || "",
  };
  currentLocation = loc;
  $("#geoDetailsPanel").style.display = "block";
  $("#dName").textContent = loc.name;
  $("#dAddress").textContent = loc.display_name || "—";
  $("#dCategory").textContent = [loc.category, loc.type].filter(Boolean).join(" / ") || "—";
  $("#dCountry").textContent = loc.country || "—";
  $("#dRegion").textContent = loc.region || "—";
  $("#dLat").textContent = loc.lat.toFixed(6);
  $("#dLon").textContent = loc.lon.toFixed(6);
  $("#gMapsBtn").href = `https://www.google.com/maps?q=${loc.lat},${loc.lon}`;
  updateGeoMap(loc);
  updateMainMap(loc);
  await loadPhotosForLocation(loc);
}
async function loadPhotosForLocation(loc) {
  $("#geoGalleryPanel").style.display = "block";
  const g = $("#geogallery"); g.innerHTML = '<p class="empty">Loading photographs…</p>';
  try {
    const photos = await fetchWikiPhotos(loc.name);
    if (!photos.length) {
      g.innerHTML = '<p class="empty">No photographs found on Wikimedia Commons for this location.</p>';
      return;
    }
    g.innerHTML = "";
    photos.forEach(p => g.appendChild(buildGalleryCard(p)));
  } catch (e) {
    console.error(e);
    g.innerHTML = '<p class="empty">Could not load photographs.</p>';
  }
}
function buildGalleryCard(p) {
  const img = el("img", { src: p.thumb, alt: p.title, loading: "lazy" });
  img.onerror = () => img.style.opacity = "0.3";
  return el("div", { class: "gallery-card" }, [
    img,
    el("div", { class: "gallery-meta" }, [
      el("span", { class: "badge-general", text: "Related image (not verified)" }),
      el("p", { text: p.title.replace(/^File:/, "") }),
      el("small", { text: `Author: ${p.author}` }),
      el("small", { text: `License: ${p.license}` }),
      el("a", { href: p.fullUrl, target: "_blank", rel: "noopener", text: "View source →" })
    ])
  ]);
}
async function copyCoords() {
  if (!currentLocation) return showToast("No location selected", true);
  const txt = `${currentLocation.lat.toFixed(6)}, ${currentLocation.lon.toFixed(6)}`;
  try { await navigator.clipboard.writeText(txt); showToast("Coordinates copied"); }
  catch {
    const ta = document.createElement("textarea");
    ta.value = txt; document.body.appendChild(ta); ta.select();
    document.execCommand("copy"); document.body.removeChild(ta);
    showToast("Coordinates copied");
  }
}
function saveCurrentLocationToCase() {
  if (!currentLocation) return showToast("No location selected", true);
  const cases = getCases();
  if (!cases.length) return showToast("Create a case first", true);
  const choices = cases.map(c => `${c.id} | ${c.title}`).join("\n");
  const input = prompt(`Enter Case ID to save this location:\n\n${choices}`, cases[0].id);
  if (!input) return;
  const target = cases.find(c => c.id === input.trim());
  if (!target) return showToast("Case not found", true);
  target.locations = target.locations || [];
  target.locations.push({ ...currentLocation, savedAt: nowISO() });
  target.updatedAt = nowISO();
  saveCases(cases);
  showToast("Location saved to case");
  refreshStats();
}

/* ---------- Cases ---------- */
function getCases() { return loadStore(STORAGE_KEYS.CASES, []); }
function saveCases(c) { saveStore(STORAGE_KEYS.CASES, c); }
function initCases() {
  $("#createCaseBtn").addEventListener("click", createCase);
}
function createCase() {
  const title = $("#caseTitle").value.trim();
  const objective = $("#caseObjective").value.trim();
  if (!title) return showToast("Case title required", true);
  const cases = getCases();
  cases.unshift({
    id: genCaseId(), title, objective,
    status: "Open", createdAt: nowISO(), updatedAt: nowISO(),
    locations: [], notes: ""
  });
  saveCases(cases);
  $("#caseTitle").value = ""; $("#caseObjective").value = "";
  showToast("Case created");
  renderCases(); refreshStats(); renderDashTimeline();
}
function renderCases() {
  const cases = getCases();
  const list = $("#caseList");
  list.innerHTML = cases.length ? "" : '<p class="empty">No cases yet.</p>';
  cases.forEach(c => {
    const item = el("div", { class: "case-item" }, [
      el("h4", { text: c.title }, [el("span", { class: `status-badge status-${c.status.replace(/\s/g, "")}`, text: c.status })]),
      el("p", { class: "case-id", text: c.id }),
      el("p", { text: `Objective: ${c.objective || "—"}` }),
      el("p", { text: `Created: ${fmtDate(c.createdAt)} • Locations: ${(c.locations || []).length}` })
    ]);
    item.addEventListener("click", () => showCaseDetail(c.id));
    list.appendChild(item);
  });
  const opts = cases.map(c => ({ value: c.id, label: `${c.id} — ${c.title}` }));
  fillSelect($("#evCase"), opts, true);
  fillSelect($("#reportCase"), opts, false);
}
function fillSelect(sel, opts, includeNone) {
  if (!sel) return;
  sel.innerHTML = "";
  if (includeNone) sel.appendChild(el("option", { value: "", text: "— Select case (optional) —" }));
  opts.forEach(o => sel.appendChild(el("option", { value: o.value, text: o.label })));
}
function showCaseDetail(id) {
  const c = getCases().find(x => x.id === id);
  if (!c) return;
  const panel = $("#caseDetailPanel"); panel.style.display = "block";
  const box = $("#caseDetail"); box.innerHTML = "";
  box.appendChild(el("h3", { text: c.title }));
  box.appendChild(el("p", { class: "case-id mono", text: c.id }));
  box.appendChild(el("p", { text: `Objective: ${c.objective || "—"}` }));
  box.appendChild(el("p", { text: `Status: ${c.status} • Created: ${fmtDate(c.createdAt)}` }));

  const statusSelect = el("select", {}, ["Open", "In Progress", "Closed"].map(s =>
    el("option", { value: s, text: s, selected: s === c.status ? "selected" : null })
  ));
  statusSelect.addEventListener("change", () => {
    c.status = statusSelect.value; c.updatedAt = nowISO();
    const all = getCases().map(x => x.id === c.id ? c : x);
    saveCases(all); showToast("Status updated"); renderCases(); refreshStats();
  });
  box.appendChild(el("div", { class: "form-row" }, [statusSelect]));

  box.appendChild(el("h4", { text: "Saved Locations" }));
  if (!c.locations?.length) box.appendChild(el("p", { class: "empty", text: "None." }));
  else c.locations.forEach((l, i) => {
    const row = el("div", { class: "case-item" }, [
      el("p", { text: `${i + 1}. ${l.name}` }),
      el("p", { class: "mono small", text: `${l.lat}, ${l.lon}` }),
      el("p", { class: "small", text: l.display_name || "" })
    ]);
    const rm = el("button", { class: "btn btn-danger", text: "Remove" });
    rm.addEventListener("click", () => {
      c.locations.splice(i, 1); c.updatedAt = nowISO();
      saveCases(getCases().map(x => x.id === c.id ? c : x));
      showCaseDetail(c.id); refreshStats();
    });
    row.appendChild(rm);
    box.appendChild(row);
  });

  box.appendChild(el("h4", { text: "Investigator Notes" }));
  const ta = el("textarea", { rows: "4" });
  ta.value = c.notes || "";
  ta.style.width = "100%";
  box.appendChild(ta);
  const saveBtn = el("button", { class: "btn btn-cyan", text: "Save Notes" });
  saveBtn.addEventListener("click", () => {
    c.notes = ta.value; c.updatedAt = nowISO();
    saveCases(getCases().map(x => x.id === c.id ? c : x));
    showToast("Notes saved");
  });
  box.appendChild(saveBtn);
}

/* ---------- Evidence ---------- */
function getEvidence() { return loadStore(STORAGE_KEYS.EVIDENCE, []); }
function saveEvidence(e) { saveStore(STORAGE_KEYS.EVIDENCE, e); }
function initEvidence() {
  $("#addEvidenceBtn").addEventListener("click", addEvidence);
}
function addEvidence() {
  const title = $("#evTitle").value.trim();
  if (!title) return showToast("Evidence title required", true);
  const list = getEvidence();
  list.unshift({
    id: "EV-" + Date.now().toString(36).toUpperCase(),
    title,
    url: $("#evUrl").value.trim(),
    caseId: $("#evCase").value,
    location: $("#evLocation").value.trim(),
    notes: $("#evNotes").value.trim(),
    collectedAt: nowISO(),
  });
  saveEvidence(list);
  $("#evTitle").value = ""; $("#evUrl").value = "";
  $("#evLocation").value = ""; $("#evNotes").value = "";
  showToast("Evidence recorded");
  renderEvidence(); refreshStats();
}
function renderEvidence() {
  const list = getEvidence();
  const box = $("#evidenceList");
  box.innerHTML = list.length ? "" : '<p class="empty">No evidence records.</p>';
  list.forEach(e => {
    const item = el("li", {}, [
      el("strong", { text: e.title }),
      el("span", { class: "mono small", text: e.id }),
      el("span", { class: "small", text: `Case: ${e.caseId || "—"} • Collected: ${fmtDate(e.collectedAt)}` }),
      e.url ? el("a", { href: e.url, target: "_blank", rel: "noopener", text: e.url, class: "small" }) : null,
      e.location ? el("span", { class: "small", text: `Location: ${e.location}` }) : null,
      e.notes ? el("span", { class: "small muted", text: e.notes }) : null,
    ]);
    const actions = el("div", { class: "ev-actions" });
    const rm = el("button", { text: "Remove" });
    rm.addEventListener("click", () => {
      saveEvidence(getEvidence().filter(x => x.id !== e.id));
      renderEvidence(); refreshStats();
    });
    actions.appendChild(rm);
    item.appendChild(actions);
    box.appendChild(item);
  });
}

/* ---------- History ---------- */
function getHistory() { return loadStore(STORAGE_KEYS.HISTORY, []); }
function saveHistory(h) { saveStore(STORAGE_KEYS.HISTORY, h.slice(0, 100)); }
function recordHistory(query, result) {
  const h = getHistory();
  h.unshift({
    q: query, ts: nowISO(),
    lat: result?.lat, lon: result?.lon,
    name: result?.display_name || "",
  });
  saveHistory(h);
  renderGeoRecent(); renderFullHistory();
}
function renderGeoRecent() {
  const list = getHistory().slice(0, 8);
  const ul = $("#geoRecent");
  ul.innerHTML = list.length ? "" : '<li class="empty">No recent searches.</li>';
  list.forEach(h => {
    const li = el("li", {}, [el("span", { text: h.q }), el("span", { class: "small muted", text: " • " + fmtDate(h.ts) })]);
    li.addEventListener("click", () => { $("#geoInput").value = h.q; runGeoSearch(h.q); });
    ul.appendChild(li);
  });
}
function renderFullHistory() {
  const list = getHistory();
  const ul = $("#fullHistory");
  ul.innerHTML = list.length ? "" : '<li class="empty">No history.</li>';
  list.forEach(h => {
    ul.appendChild(el("li", {}, [
      el("strong", { text: h.q }),
      el("div", { class: "small muted", text: fmtDate(h.ts) + (h.name ? " • " + h.name : "") })
    ]));
  });
}

/* ---------- Dashboard ---------- */
function refreshStats() {
  const cases = getCases(), ev = getEvidence();
  $("#statCases").textContent = cases.length;
  $("#statOpen").textContent = cases.filter(c => c.status !== "Closed").length;
  $("#statLocs").textContent = cases.reduce((s, c) => s + (c.locations?.length || 0), 0);
  $("#statEvidence").textContent = ev.length;
}
function renderRecentActivity() {
  const h = getHistory().slice(0, 10);
  const ul = $("#recentActivity");
  ul.innerHTML = h.length ? "" : '<li class="empty">No activity yet.</li>';
  h.forEach(x => ul.appendChild(el("li", {}, [el("span", { text: x.q }), el("span", { class: "small muted", text: " • " + fmtDate(x.ts) })])));
}
function renderDashTimeline() {
  const cases = getCases().slice(0, 6);
  const box = $("#timeline");
  box.innerHTML = cases.length ? "" : '<p class="empty">No case events recorded.</p>';
  cases.forEach(c => {
    box.appendChild(el("div", { class: "timeline-item" }, [
      el("time", { text: fmtDate(c.createdAt) }),
      el("strong", { text: c.title }),
      el("div", { class: "small muted", text: `${c.id} • ${c.status}` })
    ]));
  });
}

/* ---------- Gallery view ---------- */
function renderFullGallery() {
  if (!currentLocation) {
    $("#fullGallery").innerHTML = "";
    $("#galleryEmpty").style.display = "block";
    return;
  }
  $("#galleryEmpty").style.display = "none";
  const g = $("#fullGallery");
  if (geoGalleryHasPhotos()) {
    g.innerHTML = "";
    $$("#geogallery .gallery-card").forEach(card => g.appendChild(card.cloneNode(true)));
  } else {
    g.innerHTML = '<p class="empty">No photographs available for this location.</p>';
  }
}
function geoGalleryHasPhotos() {
  return $$("#geogallery .gallery-card").length > 0;
}

/* ---------- Report ---------- */
function initReport() {
  $("#previewReportBtn").addEventListener("click", previewReport);
  $("#downloadReportBtn").addEventListener("click", downloadReport);
  $("#printReportBtn").addEventListener("click", () => window.print());
}
function buildReport(caseId) {
  const c = getCases().find(x => x.id === caseId);
  if (!c) return null;
  const ev = getEvidence().filter(e => e.caseId === caseId);
  return { case: c, evidence: ev, generatedAt: nowISO() };
}
function previewReport() {
  const id = $("#reportCase").value;
  if (!id) return showToast("Select a case first", true);
  const r = buildReport(id);
  if (!r) return;
  const panel = $("#reportPreviewPanel"); panel.style.display = "block";
  const box = $("#reportPreview"); box.innerHTML = "";

  box.appendChild(el("h1", { text: "CyberTrace — Investigation Report" }));
  const kv = el("div", { class: "kv" });
  const rows = [
    ["Case ID", r.case.id],
    ["Title", r.case.title],
    ["Status", r.case.status],
    ["Objective", r.case.objective || "—"],
    ["Created", fmtDate(r.case.createdAt)],
    ["Generated", fmtDate(r.generatedAt)],
  ];
  rows.forEach(([k, v]) => {
    kv.appendChild(el("span", { text: k }));
    kv.appendChild(el("span", { text: v }));
  });
  box.appendChild(kv);

  box.appendChild(el("h2", { text: "Saved Locations" }));
  if (!r.case.locations?.length) box.appendChild(el("p", { class: "empty", text: "None saved." }));
  else r.case.locations.forEach((l, i) => {
    const kv2 = el("div", { class: "kv" });
    [
      [`Location ${i + 1}`, l.name],
      ["Address", l.display_name || "—"],
      ["Coordinates", `${l.lat}, ${l.lon}`],
      ["Map Link", `https://www.google.com/maps?q=${l.lat},${l.lon}`],
    ].forEach(([k, v]) => {
      kv2.appendChild(el("span", { text: k }));
      kv2.appendChild(el("span", { text: v }));
    });
    box.appendChild(kv2);
  });

  box.appendChild(el("h2", { text: "Evidence References" }));
  if (!r.evidence.length) box.appendChild(el("p", { class: "empty", text: "None recorded." }));
  else r.evidence.forEach(e => {
    box.appendChild(el("p", {}, [
      el("strong", { text: e.title }),
      el("span", { text: ` — ${e.id} • Collected ${fmtDate(e.collectedAt)}` }),
      e.url ? el("a", { href: e.url, target: "_blank", rel: "noopener", text: " [source]" }) : null,
    ]));
  });

  box.appendChild(el("h2", { text: "Investigator Notes" }));
  box.appendChild(el("p", { text: r.case.notes || "—" }));

  box.appendChild(el("h2", { text: "Data Sources" }));
  box.appendChild(el("p", { text: "Nominatim (OpenStreetMap), Wikimedia Commons, Leaflet + OpenStreetMap tiles." }));

  box.appendChild(el("div", { class: "disclaimer" },
    "DISCLAIMER: Publicly available information may be incomplete or outdated and must be independently verified. " +
    "Location search results do not constitute proof that any person, device, or suspect was present at that location."
  ));
}
function downloadReport() {
  const id = $("#reportCase").value;
  if (!id) return showToast("Select a case first", true);
  const r = buildReport(id);
  if (!r) return;
  const blob = new Blob([JSON.stringify(r, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `CyberTrace-${r.case.id}.json`;
  a.click();
  URL.revokeObjectURL(a.href);
  showToast("Report downloaded");
}

/* ---------- Settings ---------- */
function initSettings() {
  $("#clearAllBtn").addEventListener("click", () => {
    if (!confirm("Clear ALL local data? This cannot be undone.")) return;
    Object.values(STORAGE_KEYS).forEach(k => localStorage.removeItem(k));
    showToast("All local data cleared");
    refreshStats(); renderCases(); renderEvidence(); renderFullHistory();
  });
}

/* ---------- INIT ---------- */
function init() {
  startClock();
  initNav();
  initGeoSearch();
  initCases();
  initEvidence();
  initReport();
  initSettings();
  initMapFs();
  refreshStats();
  renderRecentActivity();
  renderDashTimeline();
  // Defer map init until dashboard visible
  setTimeout(() => initDashMap(), 300);
}

document.addEventListener("DOMContentLoaded", init);